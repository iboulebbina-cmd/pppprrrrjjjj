
import React from 'react';
import {
  LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend, BarChart, Bar, ComposedChart
} from 'recharts';
import { EnergyDataPoint } from '../types';

interface ChartProps {
  data: EnergyDataPoint[];
  title: string;
  type: 'house' | 'factory' | 'wind';
}

export const EnergyChart: React.FC<ChartProps> = ({ data, title, type }) => {
  if (type === 'wind') {
    return (
      <div className="h-[300px] w-full">
        <h3 className="text-lg font-bold mb-4 text-slate-700">{title}</h3>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="time" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis yAxisId="left" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
            <Tooltip 
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
            />
            <Legend verticalAlign="top" height={36}/>
            <Bar yAxisId="left" dataKey="windEnergy" name="Wind Energy (Wh)" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
            <Line yAxisId="right" type="monotone" dataKey="windSpeed" name="Wind Speed (m/s)" stroke="#0369a1" strokeWidth={3} dot={{ r: 4 }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    );
  }

  const pvKey = type === 'house' ? 'housePV' : 'factoryPV';
  const batteryKey = type === 'house' ? 'houseBattery' : 'factoryBattery';
  const gridKey = type === 'house' ? 'houseGrid' : 'factoryGrid';
  const costKey = type === 'house' ? 'houseCost' : 'factoryCost';

  return (
    <div className="h-[300px] w-full">
      <h3 className="text-lg font-bold mb-4 text-slate-700">{title}</h3>
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis dataKey="time" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis yAxisId="left" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} label={{ value: 'Watts / %', angle: -90, position: 'insideLeft', offset: 10 }} />
          <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} label={{ value: '$/kWh', angle: 90, position: 'insideRight', offset: 10 }} />
          <Tooltip 
             contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
          />
          <Legend verticalAlign="top" height={36}/>
          <Area yAxisId="left" type="monotone" dataKey={pvKey} name="Solar (W)" stroke="#f59e0b" fillOpacity={0.1} fill="#f59e0b" />
          <Line yAxisId="left" type="monotone" dataKey={batteryKey} name="Battery (%)" stroke="#10b981" strokeWidth={3} dot={false} />
          <Line yAxisId="left" type="monotone" dataKey={gridKey} name="Grid (W)" stroke="#6366f1" strokeWidth={2} strokeDasharray="5 5" dot={false} />
          <Line yAxisId="right" type="step" dataKey={costKey} name="Cost ($)" stroke="#ef4444" strokeWidth={2} dot={false} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};
