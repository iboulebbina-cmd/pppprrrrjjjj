
import { EnergyDataPoint } from '../types';

export const generateInitialHistory = (points: number = 24): EnergyDataPoint[] => {
  const history: EnergyDataPoint[] = [];
  const now = new Date();

  for (let i = points - 1; i >= 0; i--) {
    const time = new Date(now.getTime() - i * 5 * 60000); // 5 minute intervals
    history.push(generateSingleDataPoint(time));
  }
  return history;
};

export const generateSingleDataPoint = (date: Date = new Date()): EnergyDataPoint => {
  const hour = date.getHours();
  // Solar is high mid-day
  const solarFactor = Math.max(0, Math.sin((hour - 6) * Math.PI / 12));
  
  return {
    time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    houseBattery: Math.floor(40 + Math.random() * 50),
    housePV: Math.floor(solarFactor * 4000 + Math.random() * 500),
    housePVTemp: Math.floor(20 + solarFactor * 15 + Math.random() * 5),
    houseGrid: Math.floor(Math.random() * 2000),
    houseCost: Number((0.15 + Math.random() * 0.2).toFixed(2)),
    
    factoryBattery: Math.floor(60 + Math.random() * 35),
    factoryPV: Math.floor(solarFactor * 8000 + Math.random() * 1000),
    factoryPVTemp: Math.floor(25 + solarFactor * 15 + Math.random() * 5),
    factoryGrid: Math.floor(2000 + Math.random() * 5000),
    factoryCost: Number((0.20 + Math.random() * 0.4).toFixed(2)),
    
    windEnergy: Math.floor(Math.random() * 4500),
    windSpeed: Number((3 + Math.random() * 12).toFixed(1)),
    
    temperature: Math.floor(18 + Math.random() * 12),
    weather: ['Sunny', 'Cloudy', 'Rainy', 'Windy'][Math.floor(Math.random() * 4)] as any,
  };
};
