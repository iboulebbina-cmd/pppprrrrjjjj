
import { GoogleGenAI } from "@google/genai";
import { EnergyDataPoint } from "../types";

export const getEnergyInsights = async (current: EnergyDataPoint): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      As a smart energy management AI, analyze this real-time snapshot:
      - Weather: ${current.weather} (${current.temperature}°C)
      - House: Battery ${current.houseBattery}%, Solar ${current.housePV}W, Grid ${current.houseGrid}W, Cost $${current.houseCost}/kWh
      - Factory: Battery ${current.factoryBattery}%, Solar ${current.factoryPV}W, Grid ${current.factoryGrid}W, Cost $${current.factoryCost}/kWh
      - Wind: ${current.windEnergy}Wh generated at ${current.windSpeed}m/s
      
      Provide a concise 3-sentence summary of the current energy health and one actionable optimization tip (e.g., store energy, sell to grid, or switch to backup).
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "Unable to generate insights at this moment.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The AI consultant is currently offline. Please check back later.";
  }
};
